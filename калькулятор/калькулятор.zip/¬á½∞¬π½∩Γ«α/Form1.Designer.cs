﻿namespace калькулятор
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Numer4 = new Button();
            Number5 = new Button();
            Number6 = new Button();
            Number7 = new Button();
            Number8 = new Button();
            Number9 = new Button();
            Number0 = new Button();
            Addition = new Button();
            NumberMinus = new Button();
            Multiplicated = new Button();
            Division = new Button();
            sqrt = new Button();
            button_percent = new Button();
            one_div_x = new Button();
            Equalty = new Button();
            One = new Button();
            Two = new Button();
            Three = new Button();
            labelmain = new Label();
            comma = new Button();
            Delete = new Button();
            plus_minus = new Button();
            button_CE = new Button();
            m_clear = new Button();
            m_read = new Button();
            m_save = new Button();
            m_plus = new Button();
            m_minus = new Button();
            button_C = new Button();
            SuspendLayout();
            // 
            // Numer4
            // 
            Numer4.Location = new Point(10, 296);
            Numer4.Margin = new Padding(3, 4, 3, 4);
            Numer4.Name = "Numer4";
            Numer4.Size = new Size(55, 60);
            Numer4.TabIndex = 3;
            Numer4.Text = "4";
            Numer4.UseVisualStyleBackColor = true;
            Numer4.Click += Number_Click;
            // 
            // Number5
            // 
            Number5.Location = new Point(82, 296);
            Number5.Margin = new Padding(3, 4, 3, 4);
            Number5.Name = "Number5";
            Number5.Size = new Size(55, 60);
            Number5.TabIndex = 4;
            Number5.Text = "5";
            Number5.UseVisualStyleBackColor = true;
            Number5.Click += Number_Click;
            // 
            // Number6
            // 
            Number6.Location = new Point(157, 296);
            Number6.Margin = new Padding(3, 4, 3, 4);
            Number6.Name = "Number6";
            Number6.Size = new Size(55, 60);
            Number6.TabIndex = 5;
            Number6.Text = "6";
            Number6.UseVisualStyleBackColor = true;
            Number6.Click += Number_Click;
            // 
            // Number7
            // 
            Number7.Location = new Point(10, 228);
            Number7.Margin = new Padding(3, 4, 3, 4);
            Number7.Name = "Number7";
            Number7.Size = new Size(55, 60);
            Number7.TabIndex = 6;
            Number7.Text = "7";
            Number7.UseVisualStyleBackColor = true;
            Number7.Click += Number_Click;
            // 
            // Number8
            // 
            Number8.Location = new Point(82, 228);
            Number8.Margin = new Padding(3, 4, 3, 4);
            Number8.Name = "Number8";
            Number8.Size = new Size(55, 60);
            Number8.TabIndex = 7;
            Number8.Text = "8";
            Number8.UseVisualStyleBackColor = true;
            Number8.Click += Number_Click;
            // 
            // Number9
            // 
            Number9.Location = new Point(157, 228);
            Number9.Margin = new Padding(3, 4, 3, 4);
            Number9.Name = "Number9";
            Number9.Size = new Size(55, 60);
            Number9.TabIndex = 8;
            Number9.Text = "9";
            Number9.UseVisualStyleBackColor = true;
            Number9.Click += Number_Click;
            // 
            // Number0
            // 
            Number0.Location = new Point(10, 432);
            Number0.Margin = new Padding(3, 4, 3, 4);
            Number0.Name = "Number0";
            Number0.Size = new Size(137, 60);
            Number0.TabIndex = 9;
            Number0.Text = "0";
            Number0.UseVisualStyleBackColor = true;
            Number0.Click += Number_Click;
            // 
            // Addition
            // 
            Addition.Location = new Point(232, 432);
            Addition.Margin = new Padding(3, 4, 3, 4);
            Addition.Name = "Addition";
            Addition.Size = new Size(55, 60);
            Addition.TabIndex = 10;
            Addition.Text = "+";
            Addition.UseVisualStyleBackColor = true;
            Addition.Click += Addition_Click;
            // 
            // NumberMinus
            // 
            NumberMinus.Location = new Point(232, 364);
            NumberMinus.Margin = new Padding(3, 4, 3, 4);
            NumberMinus.Name = "NumberMinus";
            NumberMinus.Size = new Size(55, 60);
            NumberMinus.TabIndex = 11;
            NumberMinus.Text = "-";
            NumberMinus.UseVisualStyleBackColor = true;
            NumberMinus.Click += NumberMinus_Click;
            // 
            // Multiplicated
            // 
            Multiplicated.Location = new Point(232, 296);
            Multiplicated.Margin = new Padding(3, 4, 3, 4);
            Multiplicated.Name = "Multiplicated";
            Multiplicated.Size = new Size(55, 60);
            Multiplicated.TabIndex = 12;
            Multiplicated.Text = "*";
            Multiplicated.UseVisualStyleBackColor = true;
            Multiplicated.Click += Multiplicated_Click;
            // 
            // Division
            // 
            Division.Location = new Point(232, 226);
            Division.Margin = new Padding(3, 4, 3, 4);
            Division.Name = "Division";
            Division.Size = new Size(55, 62);
            Division.TabIndex = 13;
            Division.Text = "÷";
            Division.UseVisualStyleBackColor = true;
            Division.Click += Division_Click;
            // 
            // sqrt
            // 
            sqrt.Location = new Point(306, 160);
            sqrt.Margin = new Padding(3, 4, 3, 4);
            sqrt.Name = "sqrt";
            sqrt.Size = new Size(55, 60);
            sqrt.TabIndex = 14;
            sqrt.Text = "√x";
            sqrt.UseVisualStyleBackColor = true;
            sqrt.Click += sqrt_Click;
            // 
            // button_percent
            // 
            button_percent.Location = new Point(306, 228);
            button_percent.Margin = new Padding(3, 4, 3, 4);
            button_percent.Name = "button_percent";
            button_percent.Size = new Size(55, 60);
            button_percent.TabIndex = 15;
            button_percent.Text = "%";
            button_percent.UseVisualStyleBackColor = true;
            button_percent.Click += button_percent_Click;
            // 
            // one_div_x
            // 
            one_div_x.Location = new Point(306, 296);
            one_div_x.Margin = new Padding(3, 4, 3, 4);
            one_div_x.Name = "one_div_x";
            one_div_x.Size = new Size(55, 60);
            one_div_x.TabIndex = 16;
            one_div_x.Text = "1/x";
            one_div_x.UseVisualStyleBackColor = true;
            one_div_x.Click += one_div_x_Click;
            // 
            // Equalty
            // 
            Equalty.Location = new Point(306, 364);
            Equalty.Margin = new Padding(3, 4, 3, 4);
            Equalty.Name = "Equalty";
            Equalty.Size = new Size(55, 128);
            Equalty.TabIndex = 17;
            Equalty.Text = "=";
            Equalty.UseVisualStyleBackColor = true;
            Equalty.Click += Equalty_Click;
            // 
            // One
            // 
            One.Location = new Point(10, 364);
            One.Margin = new Padding(3, 4, 3, 4);
            One.Name = "One";
            One.Size = new Size(55, 60);
            One.TabIndex = 18;
            One.Text = "1";
            One.UseVisualStyleBackColor = true;
            One.Click += Number_Click;
            // 
            // Two
            // 
            Two.Location = new Point(82, 364);
            Two.Margin = new Padding(3, 4, 3, 4);
            Two.Name = "Two";
            Two.Size = new Size(55, 60);
            Two.TabIndex = 19;
            Two.Text = "2";
            Two.UseVisualStyleBackColor = true;
            Two.Click += Number_Click;
            // 
            // Three
            // 
            Three.Location = new Point(157, 364);
            Three.Margin = new Padding(3, 4, 3, 4);
            Three.Name = "Three";
            Three.Size = new Size(55, 60);
            Three.TabIndex = 20;
            Three.Text = "3";
            Three.UseVisualStyleBackColor = true;
            Three.Click += Number_Click;
            // 
            // labelmain
            // 
            labelmain.Font = new Font("Swis721 BlkCn BT", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            labelmain.Location = new Point(10, 30);
            labelmain.Name = "labelmain";
            labelmain.Size = new Size(360, 43);
            labelmain.TabIndex = 21;
            labelmain.Text = "0";
            labelmain.TextAlign = ContentAlignment.MiddleRight;
            // 
            // comma
            // 
            comma.Location = new Point(157, 432);
            comma.Margin = new Padding(3, 4, 3, 4);
            comma.Name = "comma";
            comma.Size = new Size(55, 60);
            comma.TabIndex = 23;
            comma.Text = ",";
            comma.UseVisualStyleBackColor = true;
            comma.Click += comma_Click;
            // 
            // Delete
            // 
            Delete.Location = new Point(10, 160);
            Delete.Margin = new Padding(3, 4, 3, 4);
            Delete.Name = "Delete";
            Delete.Size = new Size(55, 60);
            Delete.TabIndex = 24;
            Delete.Text = "←";
            Delete.UseVisualStyleBackColor = true;
            Delete.Click += Delete_Click;
            // 
            // plus_minus
            // 
            plus_minus.Location = new Point(232, 160);
            plus_minus.Margin = new Padding(3, 4, 3, 4);
            plus_minus.Name = "plus_minus";
            plus_minus.Size = new Size(55, 60);
            plus_minus.TabIndex = 25;
            plus_minus.Text = "±";
            plus_minus.UseVisualStyleBackColor = true;
            plus_minus.Click += plus_minus_Click;
            // 
            // button_CE
            // 
            button_CE.Location = new Point(82, 160);
            button_CE.Margin = new Padding(3, 4, 3, 4);
            button_CE.Name = "button_CE";
            button_CE.Size = new Size(55, 60);
            button_CE.TabIndex = 26;
            button_CE.Text = "CE";
            button_CE.UseVisualStyleBackColor = true;
            button_CE.Click += button_CE_Click;
            // 
            // m_clear
            // 
            m_clear.Enabled = false;
            m_clear.Location = new Point(10, 92);
            m_clear.Margin = new Padding(3, 4, 3, 4);
            m_clear.Name = "m_clear";
            m_clear.Size = new Size(55, 60);
            m_clear.TabIndex = 28;
            m_clear.Text = "MC";
            m_clear.UseVisualStyleBackColor = true;
            m_clear.Click += m_clear_Click;
            // 
            // m_read
            // 
            m_read.Enabled = false;
            m_read.Location = new Point(82, 92);
            m_read.Margin = new Padding(3, 4, 3, 4);
            m_read.Name = "m_read";
            m_read.Size = new Size(55, 60);
            m_read.TabIndex = 29;
            m_read.Text = "MR";
            m_read.UseVisualStyleBackColor = true;
            m_read.Click += m_read_Click;
            // 
            // m_save
            // 
            m_save.Location = new Point(157, 92);
            m_save.Margin = new Padding(3, 4, 3, 4);
            m_save.Name = "m_save";
            m_save.Size = new Size(55, 60);
            m_save.TabIndex = 30;
            m_save.Text = "MS";
            m_save.UseVisualStyleBackColor = true;
            m_save.Click += m_save_Click;
            // 
            // m_plus
            // 
            m_plus.Location = new Point(232, 92);
            m_plus.Margin = new Padding(3, 4, 3, 4);
            m_plus.Name = "m_plus";
            m_plus.Size = new Size(55, 60);
            m_plus.TabIndex = 31;
            m_plus.Text = "M+";
            m_plus.UseVisualStyleBackColor = true;
            m_plus.Click += m_plus_Click;
            // 
            // m_minus
            // 
            m_minus.Location = new Point(308, 92);
            m_minus.Margin = new Padding(3, 4, 3, 4);
            m_minus.Name = "m_minus";
            m_minus.Size = new Size(55, 60);
            m_minus.TabIndex = 32;
            m_minus.Text = "M-";
            m_minus.UseVisualStyleBackColor = true;
            m_minus.Click += m_minus_Click;
            // 
            // button_C
            // 
            button_C.Location = new Point(157, 160);
            button_C.Margin = new Padding(3, 4, 3, 4);
            button_C.Name = "button_C";
            button_C.Size = new Size(55, 60);
            button_C.TabIndex = 27;
            button_C.Text = "C";
            button_C.UseVisualStyleBackColor = true;
            button_C.Click += button_C_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(378, 561);
            Controls.Add(m_minus);
            Controls.Add(m_plus);
            Controls.Add(m_save);
            Controls.Add(m_read);
            Controls.Add(m_clear);
            Controls.Add(button_C);
            Controls.Add(button_CE);
            Controls.Add(plus_minus);
            Controls.Add(Delete);
            Controls.Add(comma);
            Controls.Add(labelmain);
            Controls.Add(Three);
            Controls.Add(Two);
            Controls.Add(One);
            Controls.Add(Equalty);
            Controls.Add(one_div_x);
            Controls.Add(button_percent);
            Controls.Add(sqrt);
            Controls.Add(Division);
            Controls.Add(Multiplicated);
            Controls.Add(NumberMinus);
            Controls.Add(Addition);
            Controls.Add(Number0);
            Controls.Add(Number9);
            Controls.Add(Number8);
            Controls.Add(Number7);
            Controls.Add(Number6);
            Controls.Add(Number5);
            Controls.Add(Numer4);
            Font = new Font("Swis721 BlkCn BT", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button Two;
        private Button Three;
        private Button Numer4;
        private Button Number5;
        private Button Number6;
        private Button Number7;
        private Button Number8;
        private Button Number9;
        private Button Number0;
        private Button Addition;
        private Button NumberMinus;
        private Button Multiplicated;
        private Button Division;
        private Button sqrt;
        private Button button_percent;
        private Button one_div_x;
        private Button Equalty;
        private Button One;
        private Label labelmain;
        private Button comma;
        private Button Delete;
        private Button plus_minus;
        private Button button_CE;
        private Button m_clear;
        private Button m_read;
        private Button m_save;
        private Button m_plus;
        private Button m_minus;
        private Button button_C;
    }
}